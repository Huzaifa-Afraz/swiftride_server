import httpStatus from "http-status";
import * as authService from "../services/auth.service.js";
import { sendSuccessResponse } from "../utils/response.js";
import catchAsync from "../utils/catchAsync.js";

// Individual signup
export const signupUser = catchAsync(async (req, res) => {
  const { fullName, email, phoneNumber, password, role } = req.body;

  const user = await authService.signupUser({
    fullName,
    email,
    phoneNumber,
    password,
    role
  });

  const tokens = authService.generateAuthToken(user);

  sendSuccessResponse(res, httpStatus.CREATED, "User registered successfully", {
    user,
    tokens
  });
});

// Individual login
export const loginUser = catchAsync(async (req, res) => {
  const { email, password } = req.body;

  const { user, tokens } = await authService.loginUser(email, password);

  sendSuccessResponse(res, httpStatus.OK, "Login successful", {
    user,
    tokens
  });
});

// Showroom signup
export const signupShowroom = catchAsync(async (req, res) => {
  const { showroomName, email, password } = req.body;

  const user = await authService.signupShowroom({
    showroomName,
    email,
    password
  });

  const tokens = authService.generateAuthToken(user);

  sendSuccessResponse(
    res,
    httpStatus.CREATED,
    "Showroom registered successfully",
    { user, tokens }
  );
});

// Showroom login
export const loginShowroom = catchAsync(async (req, res) => {
  const { email, password } = req.body;

  const { user, tokens } = await authService.loginShowroom(email, password);

  sendSuccessResponse(res, httpStatus.OK, "Login successful", {
    user,
    tokens
  });
});

// Google login (for all roles)
export const googleLogin = catchAsync(async (req, res) => {
  const { idToken, role, showroomName } = req.body;

  const { user, tokens } = await authService.googleLogin({
    idToken,
    role,
    showroomName
  });

  sendSuccessResponse(res, httpStatus.OK, "Google login successful", {
    user,
    tokens
  });
});
