import httpStatus from "http-status";
import * as kycService from "../services/kyc.service.js";
import catchAsync from "../utils/catchAsync.js";
import { sendSuccessResponse } from "../utils/response.js";

// Individual KYC (host / customer / both)
export const submitUserKyc = catchAsync(async (req, res) => {
  const userId = req.user.id; // from auth middleware

  const { idFrontUrl, idBackUrl, liveSelfieUrl, drivingLicenseUrl } = req.body;

  const kyc = await kycService.submitUserKyc(
    userId,
    { idFrontUrl, idBackUrl, liveSelfieUrl, drivingLicenseUrl }
  );

  sendSuccessResponse(res, httpStatus.CREATED, "KYC submitted successfully", {
    kyc
  });
});

// Showroom KYC
export const submitShowroomKyc = catchAsync(async (req, res) => {
  const userId = req.user.id; // showroom user

  const {
    idFrontUrl,
    idBackUrl,
    liveSelfieUrl,
    registrationCertUrl,
    taxCertUrl,
    otherDocUrl
  } = req.body;

  const kyc = await kycService.submitShowroomKyc(userId, {
    idFrontUrl,
    idBackUrl,
    liveSelfieUrl,
    registrationCertUrl,
    taxCertUrl,
    otherDocUrl
  });

  sendSuccessResponse(res, httpStatus.CREATED, "Showroom KYC submitted successfully", {
    kyc
  });
});
