import httpStatus from "http-status";
import { Kyc } from "../models/kyc.model.js";
import { User, USER_ROLE } from "../models/user.model.js";
import ApiError from "../utils/ApiError.js";

export const submitUserKyc = async (
  userId,
  { idFrontUrl, idBackUrl, liveSelfieUrl, drivingLicenseUrl }
) => {
  const user = await User.findById(userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, "User not found");
  }

  if ([USER_ROLE.CUSTOMER, USER_ROLE.BOTH].includes(user.role) && !drivingLicenseUrl) {
    throw new ApiError(
      httpStatus.BAD_REQUEST,
      "Driving license is required for customers"
    );
  }

  const existing = await Kyc.findOne({ user: userId, type: "individual" });

  if (existing) {
    existing.idFrontUrl = idFrontUrl;
    existing.idBackUrl = idBackUrl;
    existing.liveSelfieUrl = liveSelfieUrl;
    existing.drivingLicenseUrl = drivingLicenseUrl;
    existing.status = "pending";
    await existing.save();
    return existing;
  }

  const kyc = await Kyc.create({
    user: userId,
    type: "individual",
    idFrontUrl,
    idBackUrl,
    liveSelfieUrl,
    drivingLicenseUrl
  });

  return kyc;
};

export const submitShowroomKyc = async (
  userId,
  {
    idFrontUrl,
    idBackUrl,
    liveSelfieUrl,
    registrationCertUrl,
    taxCertUrl,
    otherDocUrl
  }
) => {
  const user = await User.findById(userId);
  if (!user || user.role !== USER_ROLE.SHOWROOM) {
    throw new ApiError(httpStatus.BAD_REQUEST, "Showroom user not found");
  }

  const existing = await Kyc.findOne({ user: userId, type: "showroom" });

  const payload = {
    user: userId,
    type: "showroom",
    idFrontUrl,
    idBackUrl,
    liveSelfieUrl,
    showroomDocs: {
      registrationCertUrl,
      taxCertUrl,
      otherDocUrl
    }
  };

  if (existing) {
    Object.assign(existing, payload, { status: "pending" });
    await existing.save();
    return existing;
  }

  const kyc = await Kyc.create(payload);
  return kyc;
};
