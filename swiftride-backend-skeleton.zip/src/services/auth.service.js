import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import httpStatus from "http-status";
import { OAuth2Client } from "google-auth-library";

import { User, USER_ROLE } from "../models/user.model.js";
import ApiError from "../utils/ApiError.js";

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

const sanitizeUser = (user) => {
  const obj = user.toObject();
  delete obj.password;
  return obj;
};

export const generateAuthToken = (user) => {
  const payload = {
    sub: user._id,
    role: user.role
  };

  const token = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d"
  });

  return { accessToken: token };
};

export const signupUser = async ({ fullName, email, phoneNumber, password, role }) => {
  if (!role || ![USER_ROLE.CUSTOMER, USER_ROLE.HOST, USER_ROLE.BOTH].includes(role)) {
    throw new ApiError(httpStatus.BAD_REQUEST, "Invalid role for user signup");
  }

  const existing = await User.findOne({ email });
  if (existing) {
    throw new ApiError(httpStatus.CONFLICT, "Email already registered");
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const user = await User.create({
    fullName,
    email,
    phoneNumber,
    password: hashedPassword,
    role
  });

  return sanitizeUser(user);
};

export const loginUser = async (email, password) => {
  const user = await User.findOne({ email, role: { $ne: USER_ROLE.SHOWROOM } });

  if (!user) {
    throw new ApiError(httpStatus.UNAUTHORIZED, "Invalid credentials");
  }

  const isMatch = await bcrypt.compare(password, user.password || "");
  if (!isMatch) {
    throw new ApiError(httpStatus.UNAUTHORIZED, "Invalid credentials");
  }

  const tokens = generateAuthToken(user);
  return { user: sanitizeUser(user), tokens };
};

export const signupShowroom = async ({ showroomName, email, password }) => {
  const existing = await User.findOne({ email });
  if (existing) {
    throw new ApiError(httpStatus.CONFLICT, "Email already registered");
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const showroomUser = await User.create({
    showroomName,
    email,
    password: hashedPassword,
    role: USER_ROLE.SHOWROOM
  });

  return sanitizeUser(showroomUser);
};

export const loginShowroom = async (email, password) => {
  const showroomUser = await User.findOne({ email, role: USER_ROLE.SHOWROOM });

  if (!showroomUser) {
    throw new ApiError(httpStatus.UNAUTHORIZED, "Invalid credentials");
  }

  const isMatch = await bcrypt.compare(password, showroomUser.password || "");
  if (!isMatch) {
    throw new ApiError(httpStatus.UNAUTHORIZED, "Invalid credentials");
  }

  const tokens = generateAuthToken(showroomUser);
  return { user: sanitizeUser(showroomUser), tokens };
};

export const googleLogin = async ({ idToken, role, showroomName }) => {
  if (!idToken) {
    throw new ApiError(httpStatus.BAD_REQUEST, "idToken is required");
  }

  const ticket = await googleClient.verifyIdToken({
    idToken,
    audience: process.env.GOOGLE_CLIENT_ID
  });

  const payload = ticket.getPayload();
  const email = payload.email;
  const googleId = payload.sub;
  const fullName = payload.name;

  let user = await User.findOne({ email });

  // First time google user
  if (!user) {
    let resolvedRole = role;
    if (!resolvedRole) {
      resolvedRole = USER_ROLE.CUSTOMER;
    }

    if (resolvedRole === USER_ROLE.SHOWROOM && !showroomName) {
      throw new ApiError(
        httpStatus.BAD_REQUEST,
        "showroomName is required when role is showroom"
      );
    }

    user = await User.create({
      fullName: resolvedRole === USER_ROLE.SHOWROOM ? undefined : fullName,
      showroomName: resolvedRole === USER_ROLE.SHOWROOM ? showroomName : undefined,
      email,
      role: resolvedRole,
      googleId,
      isEmailVerified: payload.email_verified
    });
  } else {
    // Link google id if missing
    if (!user.googleId) {
      user.googleId = googleId;
      await user.save();
    }
  }

  const tokens = generateAuthToken(user);

  return { user: sanitizeUser(user), tokens };
};
