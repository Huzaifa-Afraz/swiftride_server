// Placeholder for additional password helper utilities if needed later.
// For now password hashing is implemented directly in auth.service.js.
