// Reserved for future Google auth helper utilities if you want to move logic
// out of the auth.service.js file.
