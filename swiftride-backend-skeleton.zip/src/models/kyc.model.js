import mongoose from "mongoose";

const kycSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },
    type: {
      type: String,
      enum: ["individual", "showroom"],
      required: true
    },

    // Common
    idFrontUrl: { type: String, required: true },
    idBackUrl: { type: String, required: true },
    liveSelfieUrl: { type: String, required: true },

    // Individual specific (customer / host)
    drivingLicenseUrl: { type: String },

    // Showroom specific
    showroomDocs: {
      registrationCertUrl: { type: String },
      taxCertUrl: { type: String },
      otherDocUrl: { type: String }
    },

    status: {
      type: String,
      enum: ["pending", "approved", "rejected"],
      default: "pending"
    }
  },
  { timestamps: true }
);

export const Kyc = mongoose.model("Kyc", kycSchema);
