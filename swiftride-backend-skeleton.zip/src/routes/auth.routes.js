import express from "express";
import * as authController from "../controllers/auth.controller.js";

const router = express.Router();

// Individual users (host / customer / both)
router.post("/signup", authController.signupUser);
router.post("/login", authController.loginUser);

// Showroom signup + login
router.post("/showroom/signup", authController.signupShowroom);
router.post("/showroom/login", authController.loginShowroom);

// Google auth (common entry point for all roles)
router.post("/google", authController.googleLogin);

export default router;
