import express from "express";
import * as kycController from "../controllers/kyc.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = express.Router();

// KYC for individual users (host / customer / both)
router.post("/user", authenticate, kycController.submitUserKyc);

// KYC for showrooms
router.post("/showroom", authenticate, kycController.submitShowroomKyc);

export default router;
